import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { ContentGeneration } from './pages/ContentGeneration';
import { Templates } from './pages/Templates';
import { Projects } from './pages/Projects';
import { Scenarios } from './pages/Scenarios';
import { Webhooks } from './pages/Webhooks';
import { Campaigns } from './pages/Campaigns';
import { History } from './pages/History';
import { Settings } from './pages/Settings';

export type Page = 'dashboard' | 'generation' | 'templates' | 'projects' | 'scenarios' | 'webhooks' | 'campaigns' | 'history' | 'settings';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'generation':
        return <ContentGeneration />;
      case 'templates':
        return <Templates />;
      case 'projects':
        return <Projects />;
      case 'scenarios':
        return <Scenarios />;
      case 'webhooks':
        return <Webhooks />;
      case 'campaigns':
        return <Campaigns />;
      case 'history':
        return <History />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </Layout>
  );
}

export default App;